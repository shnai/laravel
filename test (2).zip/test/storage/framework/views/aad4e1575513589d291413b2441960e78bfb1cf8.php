<?php $__env->startSection('contact'); ?>

	<h1>Contact Page</h1>

	<?php if(count($people)): ?>

	<ul>
		<?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<li>
				<?php echo e($person); ?>

			</li>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
	<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>

<script type="text/javascript">alert('Hello Shani');</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>