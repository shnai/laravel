<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                	Pagination
                </div>
                <div class="panel-body">
                    <?php echo $__env->make('ajax.studebtPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).on('click','.pagination a',function(e){
            e.preventDefault();

            var page = $(this).attr('href').split('page=')[1];
            //console.log(page)
            readPage(page);
        })

        function readPage(page)
        {
            $.ajax({
                url : '/student/page/ajax?page='+page
            }).done(function(data){
                //console.log(data)
                $('.panel-body').html(data)
                location.hash=page;
            })
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>