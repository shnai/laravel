<table class="table table-bordered table-striped table-condensed">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Full Name</th>
                                <th>Sex</th>
                                <th>Action</th>
                                
                            </tr>
                        </thead>
                        <tbody id="student-info">
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="<?php echo e($student_val->id); ?>">
                                    <td><?php echo e($student_val->id); ?></td>
                                    <td><?php echo e($student_val->first_name); ?></td>
                                    <td><?php echo e($student_val->last_name); ?></td>
                                    <td><?php echo e($student_val->full_name); ?></td>
                                    <td><?php echo e($student_val->sex); ?></td>
                                    <td>
                                        
                                        <a href="#" class="btn btn-info btn-xs" id="view" data-id="<?php echo e($student_val->id); ?>">view</a>
                                        <a href="#" class="btn btn-success btn-xs" id="edit" data-id="<?php echo e($student_val->id); ?>">Edit</a>
                                        <a href="#" class="btn btn-danger btn-xs" id="del" data-id="<?php echo e($student_val->id); ?>">Delete</a>

                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
                    <?php echo e($students->render()); ?>