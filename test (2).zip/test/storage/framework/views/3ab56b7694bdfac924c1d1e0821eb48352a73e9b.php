<!DOCTYPE html>
<html>
<head>
	<title>Student Insert</title>
	<style type="text/css">
		html,body
		{
			width: 700px;
			margin: 0 auto;
		}
		table
		{
			width: 100%;
		}
	</style>
</head>
<body>
	<h1>New Student</h1>
	<a href="<?php echo e(URL::to('student/list')); ?>">Manage Student</a>
	<hr>
	<form action="<?php echo e(URL::to('/student/save')); ?>" method="POST">
	<?php echo e(csrf_field()); ?>

		<table>
			<tr>
				<th>First Name</th>
				<td><input type="text" name="first_name"></td>
			</tr>
			<tr>
				<th>Last Name</th>
				<td><input type="text" name="last_name"></td>
			</tr>
			<tr>
				<th>Sex</th>
				<td>
					<select id="sex_id" name="sex_id">
						<option value="">-- Select Sex --</option>
						<?php $__currentLoopData = $sexes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($sex->id); ?>"><?php echo e($sex->sex); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</td>
			</tr>
			<tr>
				<th colspan="2"><hr><input type="submit" name="Submit"></th>
				
			</tr>
		</table>
	</form>
</body>
</html>