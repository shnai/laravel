<!DOCTYPE html>
<html>
<head>

	<title>Ajax Page</title>
	<style type="text/css">
		html , body
		{
			width: 900px;
			margin: 0px auto;
		}
	</style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="<?php echo e(asset('js/jquery.validate.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/product_validation.js')); ?>"></script>
</head>
<body>
	<h1>Add Product</h1><hr><br>
		<div id="message" style="color: green;"></div>
		<div id="insert">
			<form action="<?php echo e(URL::to('/add_product')); ?>" method="POST" id="form-insert">
			<?php echo e(csrf_field()); ?>

			Name : <input type="text" name="name" id="name"><br><br>

			Price : <input type="text" name="price" id="price"><br><br>

			<button type="submit" class="btn green" id="insert" >Submit</button>
			</form>
		</div>
		
		<div id="update" style="display: none;">
			<form action="<?php echo e(URL::to('/update_product')); ?>" method="POST" id="form-update">

            <?php echo e(csrf_field()); ?>

                   
            <input type="hidden" name="u_id" id="u_id" >

            Name : <input type="text" name="u_name" id="u_name"><br><br>

            Price : <input type="text" name="u_price" id="u_price" ><br><br>

            <input type="submit" name="submit" value="Update">
        </form>
		</div>
	<br><br>
	<table border="1px" width="100%">
		<thead>
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Price</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody class="product">
			
		</tbody>
	</table>
</body>

<script type="text/javascript">
	window.onload = product;

	$('#form-insert').on('submit',function(e){
        e.preventDefault();
        //var data = $(this).serialize();
        //console.log(data);
        var data = $(this).serialize();
        var url = $(this).attr('action');
        var post = $(this).attr('method');
		//alert('shani');
        $.ajax({
            type:post,
            url: url,
            dataTy : 'json',
            data: {
                '_token':$('input[name=_token]').val(),
                'name':$('input[name=name]').val(),
                'price':$('input[name=price]').val(),
            },
            success:function(data){
            	product();
            	$('#insert').find('#name').val('')
            	$('#insert').find('#price').val('')
            	$("#message").append(" <b>Product</b> Addede successfully.").fadeOut(5000);
            },
        });
    })

    function edit(id)
	{	
		$("#insert").hide();
        $("#update").show();
		var id = id;
		//alert(id);
        $.ajax({
            type:'GET',
            url: 'edit_product',
            data: { id : id },
            success:function(data){
            	//alert(data);
            	//$('#update').empty();
            	//$('#update').append(html);
                $('#update').find('#u_id').val(data.id)
            	$('#update').find('#u_name').val(data.name)
            	$('#update').find('#u_price').val(data.price)
				product();
                //manage_pro();
               // $('#insertid')[0].reset();
                //window.location.reload();
            },
        });
    }


    $('#form-update').on('submit',function(e){
        e.preventDefault();
        var post = $(this).attr('method');
        var url = $(this).attr('action');
		alert(post);
		$.ajax({
            type:post,
            url: url,
            //dataTy : 'json',
            data: {
            	'id':$('input[name=u_id]').val(),
                '_token':$('input[name=_token]').val(),
                'name':$('input[name=u_name]').val(),
                'price':$('input[name=u_price]').val(),
            },
            success:function(data){
            	product();
            	$('#update').find('#u_name').val('')
            	$('#update').find('#u_price').val('')
                $("#insert").show();
                $("#update").hide();
            	$("#message").append(" <b>Product</b> Updated successfully.").fadeOut(5000);
                //manage_pro();
               // $('#insertid')[0].reset();
                //window.location.reload();
            },
        });
    })

    function del(id)
    {
    	var id = id;
    	//alert(id);
    	$.ajax({

    		type:'GET',
    		url:'delete_product',
    		data:{ id:id },
    		success:function($data){
    			$("#p_"+id).remove();
    			$("#message").append("<b>Product</b> deleted successfully").fadeOut(5000);
    		}

    	});
    }

	function product()
    {
        $.ajax({
            type:'get',
            url: 'get_product',
            dataType: 'html',
            success:function(dataType)
            {
                $('.product').html(dataType);
            }
        });
    }
</script>
</html>