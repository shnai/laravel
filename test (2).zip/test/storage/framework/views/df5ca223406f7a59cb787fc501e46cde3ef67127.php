<!DOCTYPE html>
<html>
<head>
	<title>Create page</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
	<dir class="container">
		
		<form method="POST" action="/posts">
		<?php echo e(csrf_field()); ?>

			<div class="form-group">
				<label for="title"> Title</label>
				<input type="text" name="title" class="form-control" id="title">
			</div>
			<div class="form-group">
				<label for="body"> Body</label>
				<input type="text" name="body" id="body" class="form-control">
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-primary">Post</button>
			</div>
		</form>
	</dir>
</body>
</html>