<!DOCTYPE html>
<html>
<head>
	<title>Student List</title>
	<style type="text/css">
		html,body
		{
			width: 800px;
			margin: 0 auto;
		}
		table
		{
			width: 100%;
			border-collapse: collapse;
			text-align: left;
		}
		table td ,th
		{
			border: 1px solid;
		}
	</style>
</head>
<body>
	<h1>Student List</h1>
	<hr>
	<a href="<?php echo e(URL::to('student/insert')); ?>">Add Student</a>
	<?php if(session('message')): ?>
		<h2 style="color: Green;"><?php echo e(session('message')); ?></h2>
	<?php endif; ?>
	<form action="<?php echo e(URL::to('student/multi-delete')); ?>" method="POST">
		<?php echo e(csrf_field()); ?>

	
	<table>
		<thead>
			<tr>
				<th><input type="submit" value="Delete"></th>
				<th>Id</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Full Name</th>
				<th>Sex</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><input type="checkbox" name="mult_id[]" value="<?php echo e($student->id); ?>"></td>
				<td><?php echo e($student->id); ?></td>
				<td><?php echo e($student->first_name); ?></td>
				<td><?php echo e($student->last_name); ?></td>
				<td><?php echo e($student->first_name." ".$student->last_name); ?></td>
				<td><?php echo e($student->sex); ?></td>
				<td>
					<a href="<?php echo e(URL::to('student/edit',$student->id)); ?>">Edit</a>&nbsp;&nbsp;
					<a href="<?php echo e(URL::to('student/delete',$student->id)); ?>" onclick="return confirm('Are You Sure To Delete ?')">Delete</a>
					<!--<form method="POST" action="<?php echo e(URL::to('student/delete')); ?>">
					<?php echo e(csrf_field()); ?>

						<input type="hidden" name="id" value="<?php echo e($student->id); ?>">
						<input type="submit" value="Delete">
					</form>  -->
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	</form>
</body>
</html>