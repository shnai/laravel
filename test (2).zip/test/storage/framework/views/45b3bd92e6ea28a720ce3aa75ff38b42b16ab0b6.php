<!DOCTYPE html>
<html>
<head>
	<title>Display Data</title>
	<script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
</head>
<body>
<button style="margin-left: 128px !important; margin: 11px;" id="read-data">Load Data By Ajax</button>
<center>
	<table border="1px" width="750px">
		<thead>
			<th>Id</th>
			<th>Name</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Full Name</th>
			<th>Action</th>
		</thead>
		
	</table>
</center>
</body>
<script type="text/javascript">
	$('#read-data').on('click', function(){
		$.get("<?php echo e(URL::to('student/read-data')); ?>",function(data)
		{
			$.echo(data,function(i,value)
			{
				alert(value.first_name)
			});
		})		
	})
</script>
</html>