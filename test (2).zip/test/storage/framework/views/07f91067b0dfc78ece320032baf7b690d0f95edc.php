<!DOCTYPE html>
<html>
<head>
	<title>Post Page</title>
</head>
<body>
<h1>Post : <?php echo e($id); ?> <?php echo e($name); ?> <?php echo e($password); ?></h1>
</body>
</html>