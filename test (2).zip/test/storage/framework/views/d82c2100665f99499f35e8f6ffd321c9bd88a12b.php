<?php echo e(csrf_field()); ?>

				   
			Name : <input type="text" name="u_name" id="u_name" value="<?php echo e($product->name); ?>" ><br><br>

			Price : <input type="text" name="u_price" id="u_price" value="<?php echo e($product->price); ?>" ><br><br>

			<button type="submit" class="btn green" id="insert" onclick="return update(<?php echo e($product->id); ?>)">Update</button>