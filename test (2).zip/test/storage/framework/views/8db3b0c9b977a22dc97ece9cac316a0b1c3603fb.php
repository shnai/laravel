<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">New Student Add</h4>
        </div>
        <form action="<?php echo e(URL::to('/student/store')); ?>" method="POST" id="form-insert">
          <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          <div class="col-4-md">
              <div class="form-group">
                <label> First Name</label>
                <input type="text" name="first_name" class="form-control">
              </div>
          </div>
          <div class="col-4-md">
              <div class="form-group">
                <label> Last Name</label>
                <input type="text" name="last_name" class="form-control">
              </div>
          </div>
          <div class="col-4-md">
              <div class="form-group">
                <label> Sex</label>
                <select name="sex_id" id="sex_id" class="form-control">
                  <option value="">-- Select Sex --</option>
                  <?php $__currentLoopData = $sexes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>"><?php echo e($sex); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
          </div>
        </div>
        <div class="modal-footer">
          <input type="submit" name="submit" class="btn btn-success pull-left" value="Save">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
      </div>
      
    </div>
  </div>