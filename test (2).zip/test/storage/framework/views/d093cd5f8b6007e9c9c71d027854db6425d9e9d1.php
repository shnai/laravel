<?php $__env->startSection('content'); ?>
<?php echo $__env->make('ajax.add_student', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('ajax.edit_student', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                	<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">Add Student</button>
                	<button class="btn btn-info pull-right btn-xs" id="read_deta" onclick="get_student_list()">Load Data By Ajax</button>
                </div>

                <div class="panel-body">
                    <table class="table table-bordered table-striped table-condensed">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Full Name</th>
                                <th>Sex</th>
                                <th>Action</th>
                                
                            </tr>
                        </thead>
                        <tbody id="student-info">
                        	
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script type="text/javascript">	
 window.onload = get_student_list;
	//----------------Use Ajax by Submit Data-------------
	$.ajaxSetup({
	    headers: {
	        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
	    }
	});
	//--------------------- Display Data------------------
	function get_student_list()
	{
		$("#student-info").html('');
			
		$.ajax({
			
			url: "<?php echo e(URL::to('student/resd-data')); ?>",
			cache: false,
			success: function(html)
			{
				$("#student-info").html(html);					
			}
		});
	}
	/*$('#read_deta').on('click',function(){
		$.get("<?php echo e(URL::to('student/resd-data')); ?>",function(data){

			//console.log(data);
			$('#student-info').empty().html(data);
			// $.each(data,function(i,value){
				//alert(value.first_name);
			// 	var tr =$("<tr/>");
			// 		tr.append($("<td/>",{
			// 			text : value.id
			// 		})).append($("<td/>",{
			// 			text : value.first_name
			// 		})).append($("<td/>",{
			// 			text : value.last_name
			// 		})).append($("<td/>",{
			// 			text : value.full_name
			// 		})).append($("<td/>",{
			// 			text : value.sex
			// 		})).append($("<td/>",{
			// 			html : "<a href='#'>View</a><a href='#'>Edit</a><a href='#'>Delete</a>"
			// 		}))
			// $('#student-info').append(tr);
			
			//});
		})
	})*/
	//--------------------------- Add Student---------------
	/*function insert_student()
	{
		var data = $(this).serialize();
		//console.log(data);
		var url = $(this).attr('action');
		var post = $(this).attr('method');
		$.ajax({
			type: post,
			url: url,
			data: data,
			cache: false,
			dataTy : 'json',
			success: function(data)
			{
				var tr =$("<tr/>",{
					id : data.id
				});
					tr.append($("<td/>",{
						text : data.id
					})).append($("<td/>",{
						text : data.first_name
					})).append($("<td/>",{
						text : data.last_name
					})).append($("<td/>",{
						text : data.full_name
					})).append($("<td/>",{
						text : data.sex
					})).append($("<td/>",{
						html : '<a href="#" class="btn btn-info btn-xs" id="view" data-id="'+data.id +'">view</a>			<a href="#" class="btn btn-success btn-xs" id="edit" data-id="'+data.id+'">Edit</a>			<a href="#" class="btn btn-danger btn-xs" id="del" data-id="'+data.id+'">Delete</a>'
					}))
			$('#student-info').append(tr);
			}
		});
	}*/
	$('#form-insert').on('submit',function(e){
		e.preventDefault();
		var data = $(this).serialize();
		//console.log(data);
		var url = $(this).attr('action');
		var post = $(this).attr('method');
		//alert(url);
		$.ajax({
			type : post,
			url : url,
			data : data,
			dataTy : 'json',
			success : function(data){
				get_student_list();
				/*
				var tr =$("<tr/>",{
					id : data.id
				});
					tr.append($("<td/>",{
						text : data.id
					})).append($("<td/>",{
						text : data.first_name
					})).append($("<td/>",{
						text : data.last_name
					})).append($("<td/>",{
						text : data.full_name
					})).append($("<td/>",{
						text : data.sex
					})).append($("<td/>",{
						html : '<a href="#" class="btn btn-info btn-xs" id="view" data-id="'+data.id +'">view</a>			<a href="#" class="btn btn-success btn-xs" id="edit" data-id="'+data.id+'">Edit</a>			<a href="#" class="btn btn-danger btn-xs" id="del" data-id="'+data.id+'">Delete</a>'
					}))
			//$('#modal').modal('hide');
			window.close();
			$('#student-info').append(tr);
			*/
			}
		})
	})

	//----------------Delete Student-------------

	$(document).on('click','#del',function(e){
			var id = $(this).data('id');

			//alert(id)
			$.post('<?php echo e(URL::to("student/destroy")); ?>',{id:id},function(data){

				//console.log(data)
				$('#student-info #'+id).remove();
			})

	})
	//----------------Update time get field-----------------
	$(document).on('click','#edit',function(e){

		var id = $(this).data('id')
		$.get("<?php echo e(URL::to('student/edit')); ?>",{id:id},function(data){
			//console.log(data)
			$('#form-update').find('#first_name').val(data.first_name)
			$('#form-update').find('#last_name').val(data.last_name)
			$('#form-update').find('#sex_id').val(data.sex_id)
			$('#form-update').find('#id').val(data.id)
			$('#student-update').modal('show');
		})
	})
	//---------------Update Data----
	$('#form-update').on('submit',function(e){
		e.preventDefault();
		var data = $(this).serialize();
		var url = $(this).attr('action');
		$.post(url,data,function(data){
			get_student_list();
			//console.log(data)
		// 	$('#form-update').trigger('reset')

		// 	var tr =$("<tr/>",{
		// 			id : data.id
		// 		});
		// 			tr.append($("<td/>",{
		// 				text : data.id
		// 			})).append($("<td/>",{
		// 				text : data.first_name
		// 			})).append($("<td/>",{
		// 				text : data.last_name
		// 			})).append($("<td/>",{
		// 				text : data.full_name
		// 			})).append($("<td/>",{
		// 				text : data.sex
		// 			})).append($("<td/>",{
		// 				html : '<a href="#" class="btn btn-info btn-xs" id="view" data-id="'+data.id +'">view</a>			<a href="#" class="btn btn-success btn-xs" id="edit" data-id="'+data.id+'">Edit</a>			<a href="#" class="btn btn-danger btn-xs" id="del" data-id="'+data.id+'">Delete</a>'
		// 			}))
		// 	$('#student-info tr#'+data.id).replaceWith(tr);
		 })

	})



	</script>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>