<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr id="p_<?php echo e($product_val->id); ?>">
		<td><?php echo e($product_val->id); ?></td>
		<td><?php echo e($product_val->name); ?></td>
		<td><?php echo e($product_val->price); ?></td>
		<td><button type="button" onclick="return del(<?php echo e($product_val->id); ?>)">Delete</button> <button type="button" onclick="return edit(<?php echo e($product_val->id); ?>)">Edit</button></td>
	</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>