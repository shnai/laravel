$().ready(function(){

	$("#form-insert").validate({
	
			rules:{
	
				name:'required',
				price:'required',
	
			},
	
			messages:{
	
				name:'Please enter Your Name',
				price:'Please enter Price',
	
			}
	
	});


	$("#form-insert").validate({
	
			rules:{
	
				name:'required',
				price:'required',
	
			},
	
			messages:{
	
				name:'Please enter Your Name',
				price:'Please enter Price',
	
			}
	
		});
})

$().ready(function(){


	$("#form-update").validate({
	
		rules:{

			u_name:'required',
			u_price:'required',

		},

		messages:{

			u_name:'Please enter Your Name',
			u_price:'Please enter Price',

		}
	
	});
})