<!DOCTYPE html>
<html>
<head>
	<title>Student List</title>
	<style type="text/css">
		html,body
		{
			width: 800px;
			margin: 0 auto;
		}
		table
		{
			width: 100%;
			border-collapse: collapse;
			text-align: left;
		}
		table td ,th
		{
			border: 1px solid;
		}
	</style>
</head>
<body>
	<h1>Student List</h1>
	<hr>
	<a href="{{ URL::to('student/insert') }}">Add Student</a>
	@if(session('message'))
		<h2 style="color: Green;">{{ session('message')}}</h2>
	@endif
	<form action="{{ URL::to('student/multi-delete')}}" method="POST">
		{{ csrf_field() }}
	
	<table>
		<thead>
			<tr>
				<th><input type="submit" value="Delete"></th>
				<th>Id</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Full Name</th>
				<th>Sex</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			@foreach($students as $student)
			<tr>
				<td><input type="checkbox" name="mult_id[]" value="{{ $student->id }}"></td>
				<td>{{ $student->id }}</td>
				<td>{{ $student->first_name }}</td>
				<td>{{ $student->last_name }}</td>
				<td>{{ $student->first_name." ".$student->last_name }}</td>
				<td>{{ $student->sex }}</td>
				<td>
					<a href="{{ URL::to('student/edit',$student->id) }}">Edit</a>&nbsp;&nbsp;
					<a href="{{ URL::to('student/delete',$student->id) }}" onclick="return confirm('Are You Sure To Delete ?')">Delete</a>
					<!--<form method="POST" action="{{ URL::to('student/delete')}}">
					{{ csrf_field() }}
						<input type="hidden" name="id" value="{{ $student->id }}">
						<input type="submit" value="Delete">
					</form>  -->
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>
	</form>
</body>
</html>