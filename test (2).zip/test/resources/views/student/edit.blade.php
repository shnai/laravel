<!DOCTYPE html>
<html>
<head>
	<title>Student Edit</title>
</head>
<body>
	<h1>Edit Student</h1>
	<a href="{{ URL::to('student/list')}}">Manage Student</a>
	<hr>
	<form action="{{URL::to('/student/update')}}" method="POST">
	{{ csrf_field() }}
		<input type="hidden" name="id" value="{{ $id }}">
		<table>
			<tr>
				<th>First Name</th>
				<td><input type="text" name="first_name" value="{{ $student->first_name }}"></td>
			</tr>
			<tr>
				<th>Last Name</th>
				<td><input type="text" name="last_name" value="{{ $student->last_name }}"></td>
			</tr>
			<tr>
				<th>Sex</th>
				<td>
					<select id="sex_id" name="sex_id">
						<option value="">-- Select Sex --</option>
						@foreach($sexes as $sex)
							<option value="{{ $sex->id }}" {{ $student->sex_id == $sex->id? 'selected' : null}}>{{ $sex->sex }}</option>
						@endforeach
					</select>
				</td>
			</tr>
			<tr>
				<th colspan="2"><hr><input type="submit" name="Submit"></th>
				
			</tr>
		</table>
	</form>
</body>
</html>