<!DOCTYPE html>
<html>
<head>
	<title>Student Insert</title>
	<style type="text/css">
		html,body
		{
			width: 700px;
			margin: 0 auto;
		}
		table
		{
			width: 100%;
		}
	</style>
</head>
<body>
	<h1>New Student</h1>
	<a href="{{ URL::to('student/list')}}">Manage Student</a>
	<hr>
	@if ($errors->any())
	        <ul style="color: red; list-style: none;">
	            @foreach ($errors->all() as $error)
	                <li>{{ $error }}</li>
	            @endforeach
	        </ul>
	@endif
	<form action="{{URL::to('/student/save')}}" method="POST">
	{{ csrf_field() }}
		<table>
			<tr>
				<th>First Name</th>
				<td><input type="text" name="first_name" ></td>
			</tr>
			<tr>
				<th>Last Name</th>
				<td><input type="text" name="last_name"></td>
			</tr>
			<tr>
				<th>Sex</th>
				<td>
					<select id="sex_id" name="sex_id">
						<option value="">-- Select Sex --</option>
						@foreach($sexes as $sex)
							<option value="{{ $sex->id }}">{{ $sex->sex }}</option>
						@endforeach
					</select>
				</td>
			</tr>
			<tr>
				<th colspan="2"><hr><input type="submit" name="Submit"></th>
				
			</tr>
		</table>
	</form>
</body>
</html>