			
	<form action="{{ URL::to('/update_product') }}" method="POST" id="form-update">

			{{ csrf_field() }}
				   
			<input type="hidden" name="u_id" id="u_id" value="{{ $product->id }}" >

			Name : <input type="text" name="u_name" id="u_name" value="{{ $product->name }}" ><br><br>

			Price : <input type="text" name="u_price" id="u_price" value="{{ $product->price }}" ><br><br>

			<input type="submit" name="submit" value="Update">
		</form>