@foreach($product as $product_val)
	<tr id="p_{{ $product_val->id }}">
		<td>{{ $product_val->id }}</td>
		<td>{{ $product_val->name }}</td>
		<td>{{ $product_val->price }}</td>
		<td><button type="button" onclick="return del({{ $product_val->id }})">Delete</button> <button type="button" onclick="return edit({{ $product_val->id }})">Edit</button></td>
	</tr>
@endforeach