<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Product;

class ShaniController extends Controller
{
    public function index()
    {
    	return view('shani');
    }

    public function product()
    {
    	$product = Product::get();
    	return view('product',['product'=>$product]);
    }

    public function store(Request $request)
    {	
    	$data = [

    		'name'=>$request->name,
    		'price'=>$request->price,
    		'created_at'=>date('Y-m-d h:m:s'),
    		'updated_at'=>date('Y-m-d h:m:s'),
		];
    	$product = Product::insert($data);
    	return response()->json($product);
		//return response(['message','Student Added Successfully']);
    }

    public function update(Request $request)
    {	
    	$data = [

    		'name'=>$request->name,
    		'price'=>$request->price,
    		'created_at'=>date('Y-m-d h:m:s'),
    		'updated_at'=>date('Y-m-d h:m:s'),
		];
    	$product = Product::where('id',$request->id)->update($data);
    	return response()->json($product);
		//return response(['message','Student Added Successfully']);
    }

    public function edit(Request $request)
    {
    	//$id = $request->id;
    	$product = Product::find($request->id);
    	//return view('edit_product',['product'=>$product]);

        return response($product);
    }

    public function delete(Request $request)
    {
    	//$id = $request->id;
    	$product = Product::where('id',$request->id)->delete();
    	return response($product);
    }


}
